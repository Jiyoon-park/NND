INSERT INTO memberboard (email,title,content,contentstack,techstack,likecnt)
VALUES("oks2238@naver.com","i'm learning","i'm good thank you","a","a",0);

INSERT INTO memberboard (email,title,content,contentstack,techstack,likecnt)
VALUES("hjh@gmail.com"," i'm good at algorythm","i'm from korea","a","a",0);

INSERT INTO memberboard (email,title,content,contentstack,techstack,likecnt)
VALUES("ksh@hanmail.net","i'm specialist ","i'm backend master","a","a",0);

INSERT INTO memberboard (email,title,content,contentstack,techstack,likecnt)
VALUES("lsh@naver.com","i'm leader ","i'm awsome","a","a",0);

INSERT INTO memberboard (email,title,content,contentstack,techstack,likecnt)
VALUES("lcy@hotmail.com","full stack master plz invite me"," thank you","a","a",0);

INSERT INTO memberboard (email,title,content,contentstack,techstack,likecnt)
VALUES("pjy@naver.com","front master"," bonjour","a","a",0);