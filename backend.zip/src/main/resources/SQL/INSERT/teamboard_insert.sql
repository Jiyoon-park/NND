INSERT INTO teamboard(email,teamname,groupsize,deadline,title,content,contentstack,techstack,likecnt)
VALUES("lsh@naver.com","nnd",6,"20200830","i'm leader ","i'm awsome","a","a",0);

INSERT INTO teamboard(email,teamname,groupsize,deadline,title,content,contentstack,techstack,likecnt)
VALUES("lcy@hotmail.com","nnd",6,"20200830","full stack master plz invite me"," thank you","a","a",0);

INSERT INTO teamboard(email,teamname,groupsize,deadline,title,content,contentstack,techstack,likecnt)
VALUES("pjy@naver.com","nnd",6,"20200830","front master"," bonjour","a","a",0);

INSERT INTO teamboard(email,teamname,groupsize,deadline,title,content,contentstack,techstack,likecnt)
VALUES("oks2238@naver.com","nnd",6,"20200830","i'm learning","i'm good thank you","a","a",0);

INSERT INTO teamboard(email,teamname,groupsize,deadline,title,content,contentstack,techstack,likecnt)
VALUES("hjh@gmail.com","nnd",6,"20200830"," i'm good at algorythm","i'm from korea","a","a",0);

INSERT INTO teamboard(email,teamname,groupsize,deadline,title,content,contentstack,techstack,likecnt)
VALUES("ksh@hanmail.net","nnd",6,"20200830","i'm specialist ","i'm backend master","a","a",0);
