# Sub 2

## 7/31일 회의록

*링크 : <https://docs.google.com/document/d/1RyXI1QGbLqy24XWgdm2g8VZOXOgdyR-pJffXGsupp90/edit?usp=sharing />

## 8/5 회의록

*링크 : <https://docs.google.com/document/d/1csovg8qwTEP385o6GrkLmW58iS0a3JOmsGyTHV6alOo/edit?usp=sharing />