<template>
  <v-dialog v-model="dialog" width="50%" :fullscreen="$vuetify.breakpoint.mobile" hide-overlay>
    <template v-slot:activator="{ on, attrs }">
      <i
        class="fas fa-search fa-lg"
        style="color:#777;"
        @click="dialog = true"
        dark
        v-bind="attrs"
        v-on="on"
      ></i>
    </template>
    <v-card>
      <v-toolbar dark color="indigo lighten-2">
        <v-btn icon dark @click="dialog = false">
          <v-icon>mdi-close</v-icon>
        </v-btn>
        <v-toolbar-title>검색</v-toolbar-title>
        <v-spacer></v-spacer>
      </v-toolbar>
      <v-container style="padding:3%;">
        <v-list three-line>
          <v-list-item>
            <v-combobox
              v-model="search"
              :search="search"
              hide-selected
              label="검색"
              placeholder="검색어를 입력하세요"
              multiple
              persistent-hint
              small-chips
              outlined
              class="mt-5"
              color="indigo darken-2"
            ></v-combobox>
          </v-list-item>
        </v-list>
        <i class="fas fa-filter ml-3">Filter</i>
        <v-divider></v-divider>
        <v-list three-line>
          <span class="ml-3 subheader">✔ 원하는 타입</span>
          <v-list-item>
            <v-list-item-content class="py-0">
              <div class="d-flex justify-center">
                <v-chip-group
                  v-model="typeSelection"
                  active-class="indigo lighten-1 white--text text--accent-4"
                  mandatory
                >
                  <v-chip large v-for="type in types" :key="type" :value="type">{{ type }}</v-chip>
                </v-chip-group>
              </div>
            </v-list-item-content>
          </v-list-item>
        </v-list>

        <v-list three-line>
          <span class="ml-3 subheader">✔ 원하는 카테고리</span>
          <v-list-item>
            <v-list-item-content class="py-0">
              <div class="d-flex justify-center">
                <v-switch v-model="categorySelection" label="스터디" color="red darken-3" value="스터디"></v-switch>
                <v-switch
                  v-model="categorySelection"
                  label="프로젝트"
                  color="indigo darken-3"
                  value="프로젝트"
                  class="mx-2"
                ></v-switch>
                <v-switch
                  v-model="categorySelection"
                  label="공모전"
                  color="orange darken-3"
                  value="공모전"
                ></v-switch>
              </div>
            </v-list-item-content>
          </v-list-item>
        </v-list>

        <v-list three-line>
          <span class="ml-3 subheader">✔ 원하는 기술스택</span>
          <v-list-item>
            <v-list-item-content class="py-0">
              <div class="d-flex flex-column justify-center">
                <v-combobox
                  v-model="newSkill"
                  :newSkill="newSkill"
                  label="기술스택 추가"
                  filled
                  multiple
                  dense
                  chips
                  color="indigo darken-2"
                ></v-combobox>
              </div>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-container>
      <v-divider></v-divider>
      <v-card-actions>
        <v-btn color="indigo darken-1" text class="font-weight-bold" @click="dialog = false">Close</v-btn>
        <v-spacer></v-spacer>
        <v-btn color="indigo darken-1" text class="font-weight-bold" @click="submit">Search</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { EventBus } from "../../main.js";

export default {
  data: () => ({
    dialog: false,
    search: [],
    typeSelection: [],
    categorySelection: [],
    skillSelection: [],
    newSkill: [],
    types: ["team", "member"],
    skills: ["Java", "Python", "Spring", "C", "C++", "JavaScript"],
    info: {},
    isMobile: false,
  }),
  beforeDestroy() {
    if (typeof window !== "undefined") {
      window.removeEventListener("resize", this.onResize, { passive: true });
    }
  },

  mounted() {
    this.onResize();
    window.addEventListener("resize", this.onResize, { passive: true });
  },
  methods: {
    submit() {
      //console.log(this.search);
      EventBus.$emit("search", {
        typeSelection: this.typeSelection, //팀,팀원
        search: this.search, //검색
        categorySelection: this.categorySelection, //공모전,스터디
        newSkill: this.newSkill,
      });
      this.dialog = false;
    },
    onResize() {
      this.isMobile = window.innerWidth < 600;
    },
  },
};
</script>
<style scoped>
.subheader {
  padding: 1px 0;
  background-color: #eeeeee;
  font-style: italic;
}
</style>
